﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SalesApplication.API.ALL
{
    public class SalesApplicationALL
    {

    }
}